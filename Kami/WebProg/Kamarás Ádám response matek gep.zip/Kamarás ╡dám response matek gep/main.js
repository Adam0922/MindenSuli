//Online számológép by Kami
//Licenc információk (pl.: freeware, shareware, pl: GNU GPL)
document.getElementById("sciOps").style.display = "none";
document.getElementById("btnSci").style.display = "none";

//Matek gep alaphelyzetbe
function calcReset() {
	location.reload();
}

//HTML elemek elérése változókban.
let inputA = document.querySelector("input[name='numA']");
let inputB = document.querySelector("input[name='numB']");
let errMsg = document.querySelector("span[name='errmsg']");
let output = document.querySelector("span[name='out']");
let modeText = document.querySelector("span[name='modeTXT']");

//Számolási logika megvalósítása
function calcNum() {
	debugger;
	let listOps = selOps.options[selOps.selectedIndex].innerHTML;
	//let tudOps = sciOps.options[sciOps.selectedIndex].innerHTML;
	//Számolási logika if-else algoritmussal.
	if (inputA.value == "" || inputB.value == "") {
		errMsg.innerHTML = "Nem adtál értéket";
	} else {
		errMsg.innerHTML = "";
		/*
		 	if (listOps == "+") {
				output.innerHTML = parseFloat(inputA.value) + parseFloat(inputB.value);
		 	} else if (listOps == "-") {
				output.innerHTML = parseFloat(inputA.value) - parseFloat(inputB.value);
		 	} else if (listOps == "*") {
		 		output.innerHTML = parseFloat(inputA.value) * parseFloat(inputB.value);
		 	} else if (listOps == "/") {
		 		output.innerHTML = parseFloat(inputA.value) / parseFloat(inputB.value);
		 	}
        } */
		switch (listOps) {
			case "+":
				output.innerHTML = Add(parseFloat(inputA.value), parseFloat(inputB.value));
				break;
			case "-":
				output.innerHTML = Sub(parseFloat(inputA.value), parseFloat(inputB.value));
				break;
			case "*":
				output.innerHTML = Multi(parseFloat(inputA.value), parseFloat(inputB.value));
				break;
			case "/":
				output.innerHTML = Div(parseFloat(inputA.value), parseFloat(inputB.value));
				break;
		}
		// switch (tudOps) {
		// 	case "%":
		// 		output.innerHTML = Add(parseFloat(inputA.value), parseFloat(inputB.value));
		// 		break;
		// 	case "x^":
		// 		output.innerHTML = Add(parseFloat(inputA.value), parseFloat(inputB.value));
		// 		break;
		// 	case "√":
		// 		output.innerHTML = Add(parseFloat(inputA.value), parseFloat(inputB.value));
		// 		break;
		// 	case "∛":
		// 		output.innerHTML = Add(parseFloat(inputA.value), parseFloat(inputB.value));
		// 		break;
		// 	case "log":
		// 		output.innerHTML = Add(parseFloat(inputA.value), parseFloat(inputB.value));
		// 		break;
		// 	case "sin":
		// 		output.innerHTML = Add(parseFloat(inputA.value), parseFloat(inputB.value));
		// 		break;
		// 	case "cos":
		// 		output.innerHTML = Add(parseFloat(inputA.value), parseFloat(inputB.value));
		// 		break;
		// 	case "tan":
		// 		output.innerHTML = Add(parseFloat(inputA.value), parseFloat(inputB.value));
		// 		break;
		// }
		/*
		let result = eval(parseFloat(inputA.value) + listOps + parseFloat(inputB.value));
		output.innerHTML = result.toFixed(5); */
	}
}

//Számolási logika függvényekkel.
function Add(a, b) {
	return a + b;
}
function Sub(a, b) {
	return a - b;
}
function Multi(a, b) {
	return a * b;
}
function Div(a, b) {
	return a / b;
}

function swToSci() {
	errMsg.innerHTML = "";
	inputA.value = "";
	inputB.value = "";
	modeText.innerHTML = "[Tudományos mód]";
	let sciBox = document.getElementById("cbSci");
	if (sciBox.checked == true) {
		document.getElementById("sciOps").style.display = "block";
		document.getElementById("selOps").style.display = "none";
		document.getElementById("btnDef").style.display = "none";
		document.getElementById("btnSci").style.display = "block";
	} else {
		modeText.innerHTML = "[Normál mód]";
		document.getElementById("sciOps").style.display = "none";
		document.getElementById("selOps").style.display = "block";
		document.getElementById("btnDef").style.display = "block";
		document.getElementById("btnSci").style.display = "none";
	}
}

function calcSci() {
	let listSciOps = document.getElementById("sciOps").value;
	if ((inputA.value = "")) {
		errMsg.innerHTML = "Nem adtál meg értéket";
		output.innerHTML = "0";
	} else {
	}
}

//Tudományos számolás
function Percentage(a, b) {
	let peResult = (100 * b) / a;
	return peResult;
}
function Power(a, b) {
	let pwResult = a ** b;
	return pwResult;
}
function squareRoot(a, b) {
	let sqResult = math.sqrt(a);
	return sqResult;
}
function cubeRoot(a, b) {
	let cbResult = math.cbrt(a);
	return cbResult;
}
function log(a, b) {
	let lgResult = math.log(a);
	return lgResult;
}

//Sinus kiszámítása (arrow function) használatval.
let sin = (a) => math.sin(a);

//Cosinus kiszámítása (arrow function) használatval.
let cos = (a) => math.cos(a);

//Tangens kiszámítása (arrow function) használatval.
let tan = (a) => math.tan(a);
